T0N1N0 — PRESS ASSETS / CONCEPT 01
====================================

CONTENUTO

01 / WORDMARK
T0N1N0_Wordmark_Dark.svg
T0N1N0_Wordmark_Dark.png
T0N1N0_Wordmark_Light.svg
T0N1N0_Wordmark_Light.png

02 / STACKED MARK
T0N1N0_Stacked_Dark.svg
T0N1N0_Stacked_Dark.png
T0N1N0_Stacked_Light.svg
T0N1N0_Stacked_Light.png

03 / 01 SYMBOL
T0N1N0_01_Symbol_Dark.svg
T0N1N0_01_Symbol_Dark.png
T0N1N0_01_Symbol_Light.svg
T0N1N0_01_Symbol_Light.png

UTILIZZO

- SVG: formato vettoriale, ideale per locandine, lineup, stampa e grandi dimensioni.
- PNG: formato ad alta risoluzione, ideale per social, anteprime e invii rapidi.
- Dark: fondo nero, segno bianco caldo.
- Light: fondo bianco caldo, segno nero.

IDENTITÀ

Geometria proprietaria T0N1N0, taglio di segnale orizzontale,
codice binario 0/1 e riferimenti Rome / IT.

Questi file sono una proposta locale e non sono stati caricati sul sito.
